/*
 * GetToken.cpp
 *
 *  Created on: Mar 16, 2019
 *      Author: gerardryan
 */

#include "gettoken.h"

bool	GetToken::pushed_back = false;
Token	GetToken::pushed_token;